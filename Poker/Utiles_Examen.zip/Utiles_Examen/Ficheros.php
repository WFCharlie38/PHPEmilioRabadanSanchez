<?php
/*
===========================================================
        MANEJO DE FICHEROS EN PHP - GUÍA COMPLETA
===========================================================
Autor: ChatGPT (GPT-5)
Descripción: Ejemplos básicos y avanzados de manejo de
ficheros y directorios en PHP.
===========================================================
*/

// ---------------------------------------------------------
// 1️⃣ COMPROBAR SI UN FICHERO EXISTE
// ---------------------------------------------------------
$archivo = "ejemplo.txt";

if (file_exists($archivo)) {
    echo "El archivo '$archivo' existe.<br>";
} else {
    echo "El archivo '$archivo' NO existe. Será creado.<br>";
}

// ---------------------------------------------------------
// 2️⃣ CREAR Y ESCRIBIR EN UN FICHERO
// ---------------------------------------------------------
$contenido = "Primera línea de texto.\nSegunda línea de texto.\n";

// fopen() -> abre o crea un archivo
// "w" -> escribe (borra contenido anterior o crea nuevo)
$f = fopen($archivo, "w") or die("No se puede abrir el archivo.");
fwrite($f, $contenido);
fclose($f);
echo "Archivo creado y escrito correctamente.<br>";

// ---------------------------------------------------------
// 3️⃣ AÑADIR CONTENIDO A UN FICHERO EXISTENTE
// ---------------------------------------------------------
$f = fopen($archivo, "a"); // modo append
fwrite($f, "Tercera línea (añadida).\n");
fclose($f);
echo "Línea añadida con éxito.<br>";

// ---------------------------------------------------------
// 4️⃣ LEER UN FICHERO COMPLETO
// ---------------------------------------------------------
echo "<h3>Contenido del archivo con file_get_contents():</h3>";
$todo = file_get_contents($archivo);
echo nl2br($todo); // nl2br() -> convierte \n en <br>

// ---------------------------------------------------------
// 5️⃣ LEER FICHERO LÍNEA A LÍNEA CON fgets()
// ---------------------------------------------------------
echo "<h3>Lectura línea a línea:</h3>";
$f = fopen($archivo, "r");
while (!feof($f)) { // mientras no sea fin de archivo
    $linea = fgets($f);
    echo htmlspecialchars($linea) . "<br>";
}
fclose($f);

// ---------------------------------------------------------
// 6️⃣ LEER ARCHIVO COMO ARRAY DE LÍNEAS
// ---------------------------------------------------------
$lineas = file($archivo); // cada línea como elemento del array
echo "<h3>Lectura con file():</h3>";
foreach ($lineas as $num => $linea) {
    echo "Línea " . ($num + 1) . ": " . htmlspecialchars($linea) . "<br>";
}

// ---------------------------------------------------------
// 7️⃣ COPIAR, RENOMBRAR Y BORRAR FICHEROS
// ---------------------------------------------------------
copy($archivo, "copia.txt");
rename("copia.txt", "renombrado.txt");
unlink("renombrado.txt"); // eliminar archivo
echo "<h3>Archivo copiado, renombrado y eliminado con éxito.</h3>";

// ---------------------------------------------------------
// 8️⃣ INFORMACIÓN DE UN FICHERO
// ---------------------------------------------------------
echo "<h3>Información del archivo:</h3>";
echo "Tamaño: " . filesize($archivo) . " bytes<br>";
echo "Última modificación: " . date("d/m/Y H:i:s", filemtime($archivo)) . "<br>";

// ---------------------------------------------------------
// 9️⃣ TRABAJAR CON DIRECTORIOS
// ---------------------------------------------------------
$directorio = "prueba_dir";

if (!is_dir($directorio)) {
    mkdir($directorio);
    echo "Directorio '$directorio' creado.<br>";
}

// Crear un archivo dentro del directorio
file_put_contents("$directorio/archivo1.txt", "Contenido del archivo 1\n");
file_put_contents("$directorio/archivo2.txt", "Contenido del archivo 2\n");

// Listar contenido del directorio
echo "<h3>Contenido del directorio '$directorio':</h3>";
$dir = opendir($directorio);
while (($archivo = readdir($dir)) !== false) {
    if ($archivo != "." && $archivo != "..") {
        echo " - $archivo<br>";
    }
}
closedir($dir);

// ---------------------------------------------------------
// 🔟 ELIMINAR ARCHIVOS Y DIRECTORIO (vacío)
// ---------------------------------------------------------
unlink("$directorio/archivo1.txt");
unlink("$directorio/archivo2.txt");
rmdir($directorio);
echo "<br>Directorio y archivos eliminados.<br>";

// ---------------------------------------------------------
// ✅ FUNCIONES RÁPIDAS ADICIONALES
// ---------------------------------------------------------
/*
file_put_contents("nombre.txt", "texto");
    -> crea o sobreescribe un archivo directamente.
file_get_contents("nombre.txt");
    -> lee todo el archivo de golpe.
*/

// FIN DEL SCRIPT
echo "<hr><b>FIN DEL PROGRAMA DE DEMOSTRACIÓN.</b>";
?>
