<?php
/*
====================================================
        explode() + implode() con ficheros
====================================================
*/

// 1️⃣ Creamos un archivo CSV sencillo (lista de alumnos)
$archivo = "alumnos.txt";
$alumnos = [
    ["Juan", "20", "Madrid"],
    ["Ana", "22", "Barcelona"],
    ["Luis", "19", "Valencia"]
];

$f = fopen($archivo, "w");
foreach ($alumnos as $a) {
    // Unimos el array con comas
    $linea = implode(",", $a) . "\n";
    fwrite($f, $linea);
}
fclose($f);
echo "Archivo '$archivo' creado con éxito.<br>";

// 2️⃣ Leemos el archivo y usamos explode() para procesar cada línea
$f = fopen($archivo, "r");
echo "<h3>Contenido leído con explode():</h3>";

while (!feof($f)) {
    $linea = trim(fgets($f)); // quitamos \n
    if ($linea != "") {
        $datos = explode(",", $linea); // dividimos por coma
        echo "Nombre: $datos[0] | Edad: $datos[1] | Ciudad: $datos[2]<br>";
    }
}
fclose($f);

// 3️⃣ Ahora modificamos el contenido y lo volvemos a guardar con implode()
$alumnos[0][1] = 21; // Cambiar edad de Juan
$f = fopen($archivo, "w");
foreach ($alumnos as $a) {
    fwrite($f, implode(",", $a) . "\n");
}
fclose($f);

echo "<br>Archivo actualizado con implode().<br>";
?>
