<?php
$frutas = ["manzana", "pera", "plátano", "uva"];
$texto = implode(", ", $frutas); // une con comas y espacio

echo $texto; // manzana, pera, plátano, uva
?>
