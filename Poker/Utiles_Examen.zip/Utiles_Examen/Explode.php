<?php
$texto = "manzana,pera,plátano,uva";
$frutas = explode(",", $texto); // separa por comas

print_r($frutas); // Array ( [0] => manzana [1] => pera [2] => plátano [3] => uva )

echo "<br>Primera fruta: " . $frutas[0]; // manzana
?>
